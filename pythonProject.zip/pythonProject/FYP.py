import sqlite3
import hashlib
from tkinter import *
from tkinter import simpledialog
from tkinter import messagebox
import uuid
import pyperclip
from datetime import datetime
from cryptography.fernet import Fernet
import os
import random
import string
import customtkinter


# Generate a random encryption key
def generate_key():
    return Fernet.generate_key()


# Save the encryption key securely
def save_key(key):
    with open("manager_key.key", "wb") as key_file:
        key_file.write(key)


# Load the encryption key
def load_key():
    key_file_path = "manager_key.key"
    if not os.path.exists(key_file_path):
        # If the key file doesn't exist, generate a new key and save it
        key = generate_key()
        save_key(key)
    with open(key_file_path, "rb") as key_file:
        return key_file.read()


# Encryption and Decryption functions
def encrypt_data(data):
    key = load_key()
    cipher_suite = Fernet(key)
    encrypted_data = cipher_suite.encrypt(data.encode())
    return encrypted_data


def decrypt_data(encrypted_data):
    key = load_key()
    cipher_suite = Fernet(key)
    decrypted_data = cipher_suite.decrypt(encrypted_data).decode()
    return decrypted_data


# database code
with sqlite3.connect("password_manager.db") as db:
    cursor = db.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS MasterPassword(
id INTEGER PRIMARY KEY,
Password TEXT NOT NULL,
RecoveryKey TEXT NOT NULL);
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS Manager(
id INTEGER PRIMARY KEY,
Platform TEXT NOT NULL,
Username TEXT NOT NULL,
Password TEXT NOT NULL);
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS AuditLog(
id INTEGER PRIMARY KEY,
Action TEXT NOT NULL,
Timestamp TEXT NOT NULL);
""")


# Create PopUp
def pop_up(text):
    while True:
        try:
            answer = simpledialog.askstring("Input", text, parent=window)
            if answer is None:
                return None  # If the user cancels, return None
            elif answer.strip() == "":
                messagebox.showwarning("Warning", "Please fill in the text entry.")
            else:
                return answer
        except TclError:
            manager_screen()  # Redirect to the manager screen if window is closed
            return None


# Initiate window
window = customtkinter.CTk()
window.update()
customtkinter.set_appearance_mode("system")
customtkinter.set_default_color_theme("blue")
window.title("Password Manager")

# Centering the windows
program_width = 400
program_height = 300
larger_program_width = 500
larger_program_height = 400
manager_width = 750
manager_height = 600

screen_width = window.winfo_screenwidth()
screen_height = window.winfo_screenheight()

x = (screen_width/2) - (program_width/2)
y = (screen_height/2) - (program_height/2)
xx = (screen_width/2) - (larger_program_width/2)
yy = (screen_height/2) - (larger_program_height/2)
xxx = (screen_width/2) - (manager_width/2)
yyy = (screen_height/2) - (manager_height/2)


def audit_log(action):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("INSERT INTO AuditLog(Action, Timestamp) VALUES (?, ?)", (action, timestamp))
    db.commit()


# Function to generate a random strong password
def generate_password():
    lowercase_letters = string.ascii_lowercase
    uppercase_letters = string.ascii_uppercase
    digits = string.digits
    special_characters = string.punctuation

    characters = []

    characters.append(random.choice(lowercase_letters))
    characters.append(random.choice(uppercase_letters))
    characters.append(random.choice(digits))
    characters.append(random.choice(special_characters))

    password_length = random.randint(10, 15)
    while len(characters) < password_length:
        characters.append(random.choice(string.ascii_letters + string.digits + string.punctuation))

    random.shuffle(characters)

    password = ''.join(characters)
    return password


def hash_password(password):
    hash1 = hashlib.sha256(password.encode()).hexdigest()
    return hash1


def registration():
    for widget in window.winfo_children():
        widget.destroy()
    window.geometry(f"{program_width}x{program_height}+{int(x)}+{int(y)}")

    lbl = customtkinter.CTkLabel(window, text="Registration", font=("Helvetica", 24))
    lbl.configure(anchor=CENTER)
    lbl.pack(pady=10)

    lbl = customtkinter.CTkLabel(window, text="Generated Master Password")
    lbl.configure(anchor=CENTER)
    lbl.pack(pady=10)

    # Generate a random strong password
    generated_password = generate_password()

    lbl1 = customtkinter.CTkLabel(window, text=generated_password)
    lbl1.configure(anchor=CENTER)
    lbl1.pack(pady=10)

    def copy_password():
        pyperclip.copy(generated_password)

    def save_password():
        # Hash the generated password using SHA-256
        hashed_password = hash_password(generated_password)

        # Generate a recovery key
        key = str(uuid.uuid4().hex)
        recovery_key = hash_password(key)

        # Insert the hashed password and recovery key into the database
        insert_password = "INSERT INTO MasterPassword(Password, RecoveryKey) VALUES (?, ?)"
        cursor.execute(insert_password, (hashed_password, recovery_key))
        db.commit()

        recovery_screen(key)

    btn = customtkinter.CTkButton(window, text="Copy Password", corner_radius=50, command=copy_password)
    btn.pack(pady=10)

    btn = customtkinter.CTkButton(window, text="Done", corner_radius=50, command=save_password)
    btn.pack(pady=10)


def recovery_screen(key):
    for widget in window.winfo_children():
        widget.destroy()
    window.geometry(f"{program_width}x{program_height}+{int(x)}+{int(y)}")

    lbl = customtkinter.CTkLabel(window, text="Registration", font=("Helvetica", 24))
    lbl.configure(anchor=CENTER)
    lbl.pack(pady=10)

    lbl = customtkinter.CTkLabel(window, text="Save This Key To Reset Master Password")
    lbl.configure(anchor=CENTER)
    lbl.pack(pady=10)

    lbl1 = customtkinter.CTkLabel(window, text=key)
    lbl1.configure(anchor=CENTER)
    lbl1.pack(pady=10)

    def copy_key():
        pyperclip.copy(lbl1.cget("text"))

    def done():
        login()

    btn = customtkinter.CTkButton(window, text="Copy Key", corner_radius=50, command=copy_key)
    btn.pack(pady=10)

    btn = customtkinter.CTkButton(window, text="Done", corner_radius=50, command=done)
    btn.pack(pady=10)


def reset_screen():
    for widget in window.winfo_children():
        widget.destroy()

    window.geometry(f"{program_width}x{program_height}+{int(x)}+{int(y)}")
    lbl = customtkinter.CTkLabel(window, text="Reset Password", font=("Helvetica", 24))
    lbl.configure(anchor=CENTER)
    lbl.pack(pady=10)

    txt = customtkinter.CTkEntry(window, placeholder_text="Enter Recovery Key", height=30, width=150)
    txt.pack(pady=10)

    def get_recovery_key():
        recovery_key_check = hash_password(str(txt.get()))
        cursor.execute("SELECT * FROM MasterPassword WHERE RecoveryKey = ?", (recovery_key_check,))
        return cursor.fetchall()

    def recovery_key_used():
        key_exists = get_recovery_key()

        if key_exists:
            recovery_key_check = hash_password(str(txt.get()))
            # Delete the existing entry
            cursor.execute("DELETE FROM MasterPassword WHERE RecoveryKey = ?", (recovery_key_check,))
            db.commit()
            # Proceed with registration
            registration()
        else:
            txt.delete(0, "end")
            messagebox.showinfo("Warning", "Invalid Recovery Key")

    btn = customtkinter.CTkButton(window, text="Check Key", corner_radius=50, command=recovery_key_used)
    btn.pack(pady=10)

    btn = customtkinter.CTkButton(window, text="Back", corner_radius=50, command=login)
    btn.pack(pady=10)


def login():
    for widget in window.winfo_children():
        widget.destroy()
    window.geometry(f"{program_width}x{program_height}+{int(x)}+{int(y)}")

    lbl = customtkinter.CTkLabel(window, text="Login", font=("Helvetica", 24))
    lbl.configure(anchor=CENTER)
    lbl.pack(pady=10)

    txt = customtkinter.CTkEntry(window, placeholder_text="Enter Master Password", show="*", height=30, width=150)
    txt.pack(pady=10)

    def toggle_show_password():
        current_state = txt.cget("show")
        if current_state == "*":
            txt.configure(show="")
            show_password_var.set("Hide Password")
        else:
            txt.configure(show="*")
            show_password_var.set("Show Password")

    def get_master_password():
        check_hashed_password = hash_password(txt.get())
        cursor.execute("SELECT * FROM MasterPassword WHERE id = 1 AND Password = ?", [(check_hashed_password)])
        return cursor.fetchall()

    def check_password():
        password = get_master_password()

        if password:
            audit_log("Logged in")
            # Start the timer if a timer duration is set
            check_timer()
            home_screen()
        else:
            txt.delete(0, "end")
            messagebox.showinfo("Warning", "Invalid Password")

    def reset_password():
        reset_screen()

    global show_password_var
    show_password_var = customtkinter.StringVar()
    show_password_var.set("Show Password")
    checkbox = customtkinter.CTkCheckBox(window, textvariable=show_password_var,
                                                          command=toggle_show_password)
    checkbox.pack(pady=5)

    btn = customtkinter.CTkButton(window, text="Submit", corner_radius=50, command=check_password)
    btn.pack(pady=10)

    btn = customtkinter.CTkButton(window, text="Reset Password", corner_radius=50, command=reset_password)
    btn.pack(pady=10)


def logout():
    audit_log("Logged out")
    for widget in window.winfo_children():
        widget.destroy()
    login()  # Display the login screen again after logout


def home_screen():
    for widget in window.winfo_children():
        widget.destroy()
    window.geometry(f"{larger_program_width}x{larger_program_height}+{int(xx)}+{int(yy)}")
    audit_log("Entered Home Screen")

    lbl = customtkinter.CTkLabel(window, text="Password Manager", font=("Helvetica", 24, "bold"))
    lbl.configure(anchor=CENTER)
    lbl.pack(pady=10)

    button_frame = customtkinter.CTkFrame(window, fg_color="transparent")
    button_frame.pack(pady=50)

    btn = customtkinter.CTkButton(button_frame, text="Manager", corner_radius=50, command=manager_screen)
    btn.configure(anchor=CENTER)
    btn.pack(side=LEFT, padx=50, pady=10)

    btn = customtkinter.CTkButton(button_frame, text="Settings", corner_radius=50, command=settings_screen)
    btn.configure(anchor=CENTER)
    btn.pack(side=RIGHT, padx=50, pady=10)

    button_frame = customtkinter.CTkFrame(window, fg_color="transparent")
    button_frame.pack(pady=50)

    btn = customtkinter.CTkButton(button_frame, text="Audit Log", corner_radius=50, command=audit_log_screen)
    btn.configure(anchor=CENTER)
    btn.pack(side=LEFT, padx=50, pady=10)

    btn = customtkinter.CTkButton(button_frame, text="Logout", corner_radius=50, command=logout)
    btn.configure(anchor=CENTER)
    btn.pack(side=RIGHT, padx=50, pady=10)


def back():
    for widget in window.winfo_children():
        widget.destroy()

    #Prevent the windows from altering size
    window.grid_rowconfigure(1, weight=0)  # No weight for row 1
    window.grid_columnconfigure(0, weight=0)  # No weight for column 0
    home_screen()


clipboard_protection_enabled = True  # Initial state


def toggle_clipboard_protection():
    global clipboard_protection_enabled
    clipboard_protection_enabled = not clipboard_protection_enabled
    if clipboard_protection_enabled:
        audit_log("Enabled clipboard protection")
    else:
        audit_log("Disabled clipboard protection")
    update_clipboard_message()


def update_clipboard_message():
    message = "Clipboard Protection: Enabled" if clipboard_protection_enabled else "Clipboard Protection: Disabled"
    lbl_message.configure(text=message)


def show_clipboard_protection_popup():
    messagebox.showinfo("Clipboard Protection", "Clipboard protection is enabled. Copying is disabled.")


def measure_password_strength(password):
    # Define criteria for password strength measurement
    length = len(password)
    has_lowercase = any(char.islower() for char in password)
    has_uppercase = any(char.isupper() for char in password)
    has_digit = any(char.isdigit() for char in password)
    has_special = any(char in string.punctuation for char in password)

    # Calculate password score based on criteria
    score = 0
    if length >= 8:
        score += 1
    if has_lowercase:
        score += 1
    if has_uppercase:
        score += 1
    if has_digit:
        score += 1
    if has_special:
        score += 1

    # Determine password strength based on score
    if score >= 5:
        return "Strong", []
    else:
        suggestions = []
        if length < 8:
            suggestions.append("Add more characters (at least 8 characters)")
        if not has_lowercase:
            suggestions.append("Include at least one lowercase letter")
        if not has_uppercase:
            suggestions.append("Include at least one uppercase letter")
        if not has_digit:
            suggestions.append("Include at least one digit")
        if not has_special:
            suggestions.append("Include at least one special character")

        if score >= 3:
            return "Medium", suggestions
        else:
            return "Weak", suggestions


def check_password_strength():
    password = pop_up("Enter Your Password")
    if password:
        strength, suggestions = measure_password_strength(password)
        message = f"Your password is {strength}."
        if suggestions:
            message += "\nSuggestions:\n" + "\n".join(suggestions)
        messagebox.showinfo("Password Strength", message)
        audit_log("Checked password strength")


def manager_screen():
    for widget in window.winfo_children():
        widget.destroy()

    window.geometry(f"{manager_width}x{manager_height}+{int(xxx)}+{int(yyy)}")

    # Log the action
    audit_log("Entered manager screen")

    # Main frame to hold everything
    main_frame = customtkinter.CTkFrame(window)
    main_frame.pack(fill="both", expand=True)

    # Create a canvas within the main frame with a background color that matches the dark theme
    canvas = Canvas(main_frame, bg="#333333",
                    highlightthickness=0)  # Adjust the color to match your theme and remove highlight
    canvas.pack(side="left", fill="both", expand=True)

    # Scrollbar for the canvas
    scrollbar = customtkinter.CTkScrollbar(main_frame, orientation="vertical", command=canvas.yview)
    scrollbar.pack(side="right", fill="y")

    # Configure the canvas
    canvas.configure(yscrollcommand=scrollbar.set)

    # Frame inside the canvas
    scrollable_frame = customtkinter.CTkFrame(canvas)
    scrollable_frame_id = canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")

    # Function to adjust the scrollable_frame width to fill the canvas
    def on_canvas_configure(event):
        canvas_width = event.width
        canvas.itemconfig(scrollable_frame_id, width=canvas_width)
        canvas.configure(scrollregion=canvas.bbox("all"))

    canvas.bind('<Configure>', on_canvas_configure)

    # Configure grid column weights for the scrollable_frame
    for col in range(5):
        scrollable_frame.grid_columnconfigure(col, weight=1)

    # Password Manager label
    lbl = customtkinter.CTkLabel(scrollable_frame, text="Password Manager", font=("Helvetica", 20))
    lbl.grid(row=0, columnspan=5, pady=10, sticky="ew")

    # Retrieve and display the data from the database
    cursor.execute("SELECT id, Platform, Username, Password FROM Manager")
    rows = cursor.fetchall()

    for i, (id, enc_plat, enc_user, enc_pass) in enumerate(rows):
        decrypted_platform = decrypt_data(enc_plat)
        decrypted_username = decrypt_data(enc_user)
        decrypted_password = decrypt_data(enc_pass)

        # Create StringVars for each entry
        platform_var = StringVar(value=decrypted_platform)
        username_var = StringVar(value=decrypted_username)
        password_var = StringVar(value=decrypted_password)

        # Entry for platform
        entry1 = customtkinter.CTkEntry(scrollable_frame, textvariable=platform_var, font=("Times New Roman", 12),
                                        justify="center", state="readonly", fg_color="transparent")
        entry1.grid(column=0, row=(i + 1), sticky="ew", padx=5, pady=5)

        # Entry for username
        entry2 = customtkinter.CTkEntry(scrollable_frame, textvariable=username_var, font=("Times New Roman", 12),
                                        justify="center", state="readonly", fg_color="transparent")
        entry2.grid(column=1, row=(i + 1), sticky="ew", padx=5, pady=5)

        # Entry for password
        entry3 = customtkinter.CTkEntry(scrollable_frame, textvariable=password_var, font=("Times New Roman", 12),
                                        justify="center", state="readonly", fg_color="transparent")
        entry3.grid(column=2, row=(i + 1), sticky="ew", padx=5, pady=5)

        # Delete button
        btn_delete = customtkinter.CTkButton(scrollable_frame, text="Delete", corner_radius=50, command=lambda id=id: delete_entry(id))
        btn_delete.grid(column=3, row=(i + 1), sticky="ew", padx=5, pady=5)

        # Update button
        btn_update = customtkinter.CTkButton(scrollable_frame, text="Update", corner_radius=50,
                                             command=lambda id=id: update_entry(id, platform_var, username_var,
                                                                                password_var))
        btn_update.grid(column=4, row=(i + 1), sticky="ew", padx=5, pady=5)

        # Bind events to show clipboard protection popup if enabled
        if clipboard_protection_enabled:
            entry1.bind("<Button-1>", lambda event: show_clipboard_protection_popup())
            entry2.bind("<Button-1>", lambda event: show_clipboard_protection_popup())
            entry3.bind("<Button-1>", lambda event: show_clipboard_protection_popup())

    # Add entry button
    btn = customtkinter.CTkButton(window, text="Add Entry", corner_radius=50, command=add_entry)
    btn.pack(pady=20)

    btn = customtkinter.CTkButton(window, text="Check Password Strength", corner_radius=50,
                                                 command=check_password_strength)
    btn.pack(pady=10)

    # Back button
    btn = customtkinter.CTkButton(window, text="Back", corner_radius=50, command=back)
    btn.pack(pady=20)


def add_entry():
    platform = pop_up("Platform")
    if platform is None:
        return

    username = pop_up("Username")
    if username is None:
        return

    password = pop_up("Password")
    if password is None:
        return

    encrypted_platform = encrypt_data(platform)
    encrypted_username = encrypt_data(username)
    encrypted_password = encrypt_data(password)

    cursor.execute("INSERT INTO Manager(Platform, Username, Password) VALUES(?, ?, ?)",
                   (encrypted_platform, encrypted_username, encrypted_password))
    db.commit()
    audit_log("Added entry")
    manager_screen()  # Refresh manager screen after adding an entry

def delete_entry(entry_id):
    cursor.execute("DELETE FROM Manager WHERE id = ?", (entry_id,))
    db.commit()
    audit_log("Deleted entry")
    manager_screen()  # Refresh manager screen after deleting an entry

def update_entry(entry_id, platform_var, username_var, password_var):
    platform = platform_var.get()
    username = username_var.get()
    updated_password = pop_up("Update Password")
    if updated_password is None or updated_password.strip() == "":
        return  # Do nothing if the password is not provided or is empty

    encrypted_platform = encrypt_data(platform)
    encrypted_username = encrypt_data(username)
    encrypted_password = encrypt_data(updated_password)

    cursor.execute("UPDATE Manager SET Platform = ?, Username = ?, Password = ? WHERE id = ?",
                   (encrypted_platform, encrypted_username, encrypted_password, entry_id))
    db.commit()
    audit_log("Updated entry")
    manager_screen()


def clear_clipboard():
    # Clear the clipboard history
    pyperclip.copy("")
    print("Clipboard cleared")


timer_file = "timer.txt"


def set_timer_popup():
    global timer_duration
    timer_input = simpledialog.askstring("Set Timer", "Enter timer duration (in seconds):", parent=window)
    if timer_input is not None:
        try:
            if timer_input.strip() == "":
                messagebox.showwarning("Warning", "Please fill in the text field")
                return
            timer_duration = int(timer_input)
            if timer_duration <= 0:
                messagebox.showwarning("Warning", "Timer duration must be a positive integer.")
                return
            # Save the timer duration to a file for persistence
            with open(timer_file, "w") as f:
                f.write(str(timer_duration))
                audit_log(f"Timer set to {timer_duration} seconds")
            messagebox.showinfo("Timer Set", f"Timer set to {timer_duration} seconds")
            # Start the timer
            check_timer()
        except ValueError:
            if not timer_input.isdigit():
                messagebox.showwarning("Warning", "Please enter a valid integer value for the timer duration.")


def read_timer_duration():
    if os.path.exists(timer_file):
        with open(timer_file, "r") as f:
            duration_str = f.read()
            return int(duration_str)
    else:
        return None


def check_timer():
    if timer_duration is not None:
        # Schedule the function to clear clipboard history after the timer duration
        window.after(timer_duration * 1000, clear_clipboard)
        # Schedule the check_timer function to run again after the timer duration
        window.after(timer_duration * 1000, check_timer)


# Read timer duration from the file at the start of the application
timer_duration = read_timer_duration()


def settings_screen():
    for widget in window.winfo_children():
        widget.destroy()

    window.geometry(f"{program_width}x{program_height}+{int(x)}+{int(y)}")
    audit_log("Entered settings screen")

    lbl = customtkinter.CTkLabel(window, text="Settings", font=('Helvetica', 24))
    lbl.pack(pady=10)

    global lbl_message
    lbl_message = customtkinter.CTkLabel(window, text="")
    lbl_message.pack(pady=10)
    update_clipboard_message()  # Update message label initially

    btn_toggle_clipboard = customtkinter.CTkButton(window, text="Toggle Clipboard Protection", corner_radius=50, command=toggle_clipboard_protection)
    btn_toggle_clipboard.pack(pady=10)

    btn_set_timer = customtkinter.CTkButton(window, text="Set Clear Clipboard Timer", corner_radius=50, command=set_timer_popup)
    btn_set_timer.pack(pady=10)

    btn = customtkinter.CTkButton(window, text="Back", corner_radius=50, command=back)
    btn.pack(pady=10)

    # Start the timer if a timer duration is set
    check_timer()


def clear_audit_log():
    # Delete all entries from the AuditLog table
    cursor.execute("DELETE FROM AuditLog")
    db.commit()
    # Refresh the audit log screen to reflect the changes
    audit_log_screen()


def audit_log_screen():
    for widget in window.winfo_children():
        widget.destroy()
    audit_log("Entered Audit Log")
    window.geometry(f"{larger_program_width}x{larger_program_height}+{int(xx)}+{int(yy)}")
    window.title("Audit Log")

    lbl_title = customtkinter.CTkLabel(window, text="Audit Log", font=('Helvetica', 24))
    lbl_title.grid(row=0, column=0, columnspan=2, pady=10)

    # Create a Text widget to display the audit log
    text_log = customtkinter.CTkTextbox(window, width=80, height=25, font=("Arial", 12))
    text_log.grid(row=1, column=0, columnspan=2, padx=10, pady=10, sticky="nsew")

    # Fetch the audit log entries from the database
    cursor.execute("SELECT * FROM AuditLog")
    logs = cursor.fetchall()

    # Iterate over the log entries and append them to the Text widget
    for log in logs:
        action = log[1]
        timestamp = log[2]
        log_entry = f"{timestamp} - {action}\n"
        text_log.insert(END, log_entry)

    # Disable text editing in the Text widget
    text_log.configure(state=DISABLED)

    # Configure grid weights to allow the Text widget to expand
    window.grid_rowconfigure(1, weight=1)
    window.grid_columnconfigure(0, weight=1)

    # Add a button to clear the audit log on the left
    btn_clear_log = customtkinter.CTkButton(window, text="Clear Audit Log", corner_radius=50, command=clear_audit_log)
    btn_clear_log.grid(row=2, pady=10, padx=10, sticky="w")  # Set sticky to "w" for left alignment

    # Add the "Back" button on the right
    btn_back = customtkinter.CTkButton(window, text="Back", corner_radius=50, command=back)
    btn_back.grid(row=2, pady=10, padx=10, sticky="e")


cursor.execute("SELECT * FROM MasterPassword")
if (cursor.fetchall()):
    login()
else:
    registration()
window.mainloop()